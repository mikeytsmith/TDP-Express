const express = require('express'); //importing express into index.js - had already npm init-y and npm install express on bash terminal

const app = express(); // initialising it.

const bodyParser = require('body-parser');
app.use(bodyParser.json()); // converts the request body from JSON (res=> res.json())

const cors = require('cors');
app.use(cors());

//import routes into index
const nameRouter = require('./routes/names');
app.use('/names', nameRouter);

const movieRouter = require('./routes/movie');
app.use('/movie', movieRouter);

//log details to console then passes through next function
app.use((req, res, next) => {
    const logEntry = `host: ${req.host}
    ip: ${req.ip}
    method: ${req.mthod}
    path: ${req.path}
    time: ${new Date()}`;
    console.log(logEntry);
    next();
});

// sends a request to page that pringts greeting and my name. 
app.get('/', (req, res) => // request handeler listens for GET requests at '/' 
    res.send("Hello, my name is MS!")); // once sees request of '/' responds with the below.

//error message catches 404s
app.use('*', (req, res, next) => next({ status: 404, message: 'Invalid URL' }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
    res.status(err.status ? err.status : 500).send(err.message);
});

const server = app.listen(4400, () => { //delcares the variable server which is being told to listen on port 4400?
    console.log("server started on", server.address().port); //output the server address. 
});
