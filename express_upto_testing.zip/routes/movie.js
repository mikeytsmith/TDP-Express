const router = require('express').Router();
const movieMongoose = require('../db');
const movie = require('../db');


// fetch data from url 4400/movie and welcome to this page 
router.get('/', (req, res) => // request handeler listens for GET requests at '/' 
    res.send("Hello, hopefuly this is on the movie page")); // once sees request of '/' responds with the below.

// create
router.post('/create', (req, res) => { // request handler listens for POST request at /create
    const newMovie = req.body; // varaible newname will be set by the request in the body with the key newname?
       
        for (let title of newMovie) {
            movie.create(newMovie)
            .then((result)=> res.status(201).send($result) `added successfully`)
            .catch((err) => next(err));
        } 
    // response to user to show the name was added successfully. 
    // for this i went to postman selected post - typed in the URL with /create on the end
    // selected body > raw and JSON. 
    // typed in an array in the text box feild {"name" : "Steve"}
    // this then gets added to the output'Steve' to the list of names of a get all browser refresh. 
});

//READ ALL

router.get('readAll', (req,res) => {
    movie.find()
        .then((result) => res.send(result))
        .catch((err) => ext(err));
});

//READ ONE
router.get('/readOne', (req,res) => {
    movie.find( {name: "Star Wars"} )
        .then((result) => res.send(result))
        .catch((err) => next(err));
});

//UPDATE
router.put('/update/:id', (req,res, next) => {
    const id = req.params.id;
    const newMovie = req.body;

    movie.findByIdAndUpdate(id, newMovie)
    .then ((result) => res.send(result))
    .catch((err) => next(err));
});

//DELETE
router.delete('/delete/:id', (req ,res, next) => {
    const id = req.params.id;

    movie.findByIdAndDelete(id)
    .then(() => res.status(204).send())
    .catch((err) => next(err));
});

module.exports = router;
