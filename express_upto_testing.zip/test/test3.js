const mocha = require('mocha');
const chai = require('chai');
const doggos = require('./doggos');


mocha.describe("Test doggos", () => {
// describe is a collection of tests. test suite for testing functions - i could test dfferent files on one test file. 
// just need to say it requires the relevant file. 
    mocha.it('should not show 12th place', () =>{
        // - it is used to describe the expected outcome
        chai.expect().to.equal(doggos.showDogs(12));
        //expect is expectation of the test result. 
    })
    });
