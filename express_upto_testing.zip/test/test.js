const mocha = require('mocha');
const chai = require('chai');
const maths = require('./maths');

mocha.describe("Test adding", () => {
// describe is a collection of tests. test suite for testing functions
    mocha.it('should equal 2', () =>{
        // - it is used to describe the expected outcome
        chai.expect(2).to.equal(maths.add(1,1));
        //expect is expectation of the test result. 
    });
    mocha.it('should equal 4', () =>{
        chai.expect(4).to.equal(maths.add(2,2));
    });
    mocha.it('should equal 10', () =>{
        chai.expect(10).to.equal(maths.add(5,6));
        // delieberately wrong so output shows that it expects 11 to be equal to 10
    });
});

