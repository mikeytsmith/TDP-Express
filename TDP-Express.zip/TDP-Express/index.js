const express = require("express"); // importing express into index.js

const app = express(); // inintialising it.

const server = app.listen(4494, () => {
console.log("Server started on", server.address().port);
});