const mocha = require('mocha');
const chai = require('chai');
const factorial = require('./factorials');

mocha.describe("Test factorials", () => {
// describe is a collection of tests. test suite for testing functions
    mocha.it('should equal 5!', () =>{
        // - it is used to describe the expected outcome
        chai.expect(factorial(120)).to.equal('5!');
        //expect is expectation of the test result. 
    })
    mocha.it('should equal 6!', () =>{
        // - it is used to describe the expected outcome
        chai.expect(factorial(720)).to.equal('6!');
        //expect is expectation of the test result. 
    })
    mocha.it.skip('should equal 5!', () =>{
        // - it is used to describe the expected outcome
        chai.expect(factorial(1200)).to.equal('5!');
        //expect is expectation of the test result. 
    })
    });
