const mocha = require('mocha');
const chai = require('chai');
const doggos = require('./doggos');


mocha.describe("Test doggos", () => {
// describe is a collection of tests. test suite for testing functions - i could test dfferent files on one test file. 
// just need to say it requires the relevant file. 
    mocha.it('should not show 12th place', () =>{
        // - it is used to describe the expected outcome
        chai.expect('12th').to.not.equal(doggos.showDogs(12));
        //expect is expectation of the test result. 
    })
    mocha.it('should not show 47th place', () =>{
        // - it is used to describe the expected outcome
        chai.expect('47th').to.not.equal(doggos.showDogs(47));
        //expect is expectation of the test result. 
    })
    mocha.it('should not show 83rd place', () =>{
        // - it is used to describe the expected outcome
        chai.expect('83rd').to.not.equal(doggos.showDogs(83));
        //expect is expectation of the test result. 
    })
    mocha.it('should not show 31st place', () =>{
        // - it is used to describe the expected outcome
        chai.expect('31st').to.not.equal(doggos.showDogs(31));
        //expect is expectation of the test result. 
    })
    mocha.it('should have 99 results', () => {
        chai.expect(doggos.showDogs(1)).to.have.lengthOf.below(100);
    });
    mocha.it('should have 99 results', () => {
        chai.expect(doggos.showDogs(1)).to.have.lengthOf(99);
    });
 });
