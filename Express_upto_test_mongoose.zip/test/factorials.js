// for(let i = 0; i < 10; i++) {
    // console.log(i);
// }

//120 => 120/2> 60/3 > 20/4 > 5/5 => 1 =>5!

// let num = 120;
// creates a function to figure out factorial based num variable
    function factorial(num) {
        // declare i variable, for looping purposes set to 1 is a factorial
        let i = 1;
    // run this loop while num does not equal 1
while (num > 1) { 
    // icrease by 1
    i++;
    // then divide num by i and reassign num value to calcualtion
     num /= i;
};

    //  if loop that retuns value calculated by the while loop
     if (num < 1) {
        //  if num value is less than value 1, return error message
         return('error - Not a factorial');
        
     }
     //  if is equal to 1, we log i to show the factorial number (number of times i ran through loop) and ! to denote it is a factorial
        else if (num == 1) {
       return i +'!';
    } 
    };
// logs the num stated above ans the factorial calcualted in function
// console.log(`${num} has a factorial of ${factorial(num)}`);

module.exports = factorial;