function showDogs (myDog) {
const dog = []; // creates blank array 
// creates values for array from 1-100 using for loop.
for (let i = 1; i<101; i++) {

    if (i == myDog){
            continue;
        }
        let position = i;
        
        if (position % 10 == 1 && position != 11){
            position += 'st';
        } else if (position % 10 == 2 && position != 12){
            position += 'st';
        } else if (position % 10 == 3 && position != 13){
            position += 'st';
        }else {
            position += 'th';
        };

    // pushes loop reults for position to array dog
    dog.push(position);
}
// loops through array and changes value of ndex to spoken english

return dog;

}
console.log(showDogs(12));
// exports the showdogs function so it can be imported elsewhere
module.exports = {showDogs};

        // way we did it before being told about modulus
        // if (position == 1 || position == 21 || position == 31 || position == 41 || position == 51 || position == 61 || position == 71 ||position == 81 || position == 91 ) {
        //     position += 'st';
        // } else if (position == 2 || position == 22 || position == 32 || position == 42 || position == 52 || position == 62 || position == 72 ||position == 82 || position == 92) {
        //      position += 'nd';
        // } else if (position == 3 || position == 23 || position == 33 || position == 43 || position == 53 || position == 63 || position == 73 ||position == 83 || position == 93){
        //      position += 'rd';
        // }else {
        //      position += 'th';
        // };