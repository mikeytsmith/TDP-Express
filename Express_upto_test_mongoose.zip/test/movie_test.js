const mocha = require('mocha');
const chai = require('chai');
const chaiHttp = require('chai-http');

//imported chai http and added it to our chai
chai.use(chaiHttp);

const server = require('../index');
const movieMongoose = require('../db');

mocha.describe('CRUD testing', () => {
    let id;
    mocha.beforeEach((done) => {
        movieMongoose.deletemany({}).then(() => {
        movieMongoose.create({
            name: "Star Wars",
            description: "lightsabers, jedi, blasters - pew pew.",
            duration: 120,
        }).then((result) => {
            id = reslut._id;
            done();
        }).catch((err) => console.error(err));
    }).catch((err) => console.error(err));
   }); 
    

    mocha.it('should create a movie', (done) => {
     const requestBody = {
        
        name: 'secret life of walter mitty',
        description: "Walter, who has never done anything, travels the world to hunt down a missing photo for his magazines front cover",
        duration: '110',
        };
        chai.request(server).post('/movie/create').send(requestBody).end((err, res) =>{
            chai.expect(err).to.be.null;
            chai.expect(res.status).to.equal(201);
            chai.expect(res.body).to.include(requestBody);

        });
    });
   
    mocha.it('Should update a movie', (done) => {
      chai.request(server).put(`/movie/update/${id}`).send({
        name: 'Lock Stock',
        description: "boxng promoters get tangle up with gangsters and pikeys trying to make ammends for ruining a fixed fight.",
        duration: 129,
      }).end((err, res) => {
        chai.expect(err).to.be.null;
        chai.expect(res.status).to.equal(202);
        chai.expect(res.body).to.include({
            name: 'Lock Stock',
            description: "boxng promoters get tangle up with gangsters and pikeys trying to make ammends for ruining a fixed fight.",
            duration: 129,
        });
        done();   
      });
    });

    mocha.it('Should delete a movie', (done) => {
        chai.request(server).delete(`/movie/delete/${id}`).end((err,res) => {
            chai.expect(err).to.be.null;
            chai.expect(res.status).to.equal(204);
             done(); 
        });
    }); 

    mocha.it('Should read all movies', (done) => {
    // tell chai to request server, get all objects from this file path, then end to say we dont expect and error
     chai.request(server).get('/movie/readAll').end((err,res) => {
         chai.expect(err).to.be.null;
         chai.expect(res.status).to.equal(200);
         done(); 
        });
    });
});
