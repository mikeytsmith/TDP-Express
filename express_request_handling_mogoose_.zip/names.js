const router = require('express').Router();

let names = ['MS', 'LJ', 'MP', 'TF']; // created non constant array of names called names. 

router.get('/getAll', (req, res) => res.send(names)); // request handeler listens for GET requests at 'getall'. if sees this in browser returns all in names array.

router.get('/get/:id', (req, res, next) => {
    //request handeler listens for GET requests at the index specified (0-3)
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id) || id < 0 || id >= names.length)
        return next({ status: 400, message: "Invalid id" });
    return res.send(names[id]); // reponds with name vvariable whose index is the one specified by the request
});



router.post('/create', (req, res) => { // request handler listens for POST request at /create
    const newName = req.body.name; // varaible newname will be set by the request in the body with the key newname?
    names.push(newName); //adds this new name variable to the list of names variable 
    res.send(`${newName} added successfully`); // response to user to show the name was added successfully. 
    // for this i went to postman selected post - typed in the URL with /create on the end
    // selected body > raw and JSON. 
    // typed in an array in the text box feild {"name" : "Steve"}
    // this then gets added to the output'Steve' to the list of names of a get all browser refresh. 
});

//adds multiple names from postman to array created in JS
router.post('/multipleNames', (req, res) => {
    const newName = req.body;

    for (let person of newName) {
        names.push(person.newName);
    }

    res.status(201).send(`Names added successfully`);
    // this time on postman i would need to select post - then /multiplenames URL.
    // select same options again. then create an array so use [] around all options, {}, around each option
});

// Replaces a name in the array with a name specified in a querey parameter at an index specified in a URL Parameter
router.put('/updateName/:id', (req, res, next) => {
    // pulls through name from postman e.g. http://localhost:4400/updateName/0?name=Michael
    // in the above url, we are taking the the index/id which is 0 (MS currently), and the new name,which is Michael.
    const newName = req.query.name;
    const id = parseInt(req.params.id, 10);

    if (Number.isNaN(id) || id < 0 || id >= names.length)
        return next({ status: 400, message: "Invalid id" });
    // states old name if from the JS array at the same id
    const oldName = names[id];
    //takes location of old name, and uses to update old name to new name from postman
    names[id] = newName;
    names.splice(id, 1, newName);
    //confirms the changes have been made
    return res.status(202).send(`${oldName} successfully replaced with ${names[id]}`);
});

router.get('/delete/:id', (req, res, next) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id) || id < 0 || id >= names.length)
        return next({ status: 400, message: "Invalid id" });
    names.splice(id, 1, newName);
    return res.status(204).send(); // should delete the name at the index specified in the URL parameter but this didnt work
});

module.exports = router;