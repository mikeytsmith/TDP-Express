const router = require('express').Router();
const mongoose = require("mongoose");

const Schema = mongoose.Schema;

// connects to a mongoDB database, if it does not exist will create one.
mongoose.connect('mongodb://localhost:27017/TDP-DB', { useNewUrlParser: true }, (err) => {
    // the first bit is outlining the server. the /TDP-DB bit is the specific database. 
    if (err) return console.error(err);
    return console.log('Connection successful')
});
const movieSchema = new Schema({
    name: {
        type: String,
        min: 2,
        required: true
    },

    description: {
        type: String,

    },
    duration: {
        type: Number,
        min: 2,
        required: true
    },
});
const movie = mongoose.model("movie", movieSchema)

module.exports = movie;