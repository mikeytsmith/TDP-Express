const express = require('express'); //importing express into index.js - had already npm init-y and npm install express on bash terminal

const app = express(); // initialising it.

const bodyParser = require('body-parser');

app.use(bodyParser.json()); // converts the request body from JSON (res=> res.json())

app.get('/', (req,res) => // request handeler listens for GET requests at '/' 
res.send("Hello, my name is MS!")); // once sees request of '/' responds with the below.

let names = ['MS', 'LJ', 'MP', 'TF']; // created non constant array of names called names. 

app.get('/getAll', (req,res) => res.send(names)); // request handeler listens for GET requests at 'getall'. if sees this in browser returns all in names array.

app.get('/get/:id', (req, res) => //request handeler listens for GET requests at the index specified (0-3)
res.send(names[req.params.id]) // reponds with name vvariable whose index is the one specified by the request
);

app.get('/delete/:id', (req,res) => {
    res.send(names.splice(req.params.id,1)); // should delete the name at the index specified in the URL parameter but this didnt work
});

app.post('/create', (req,res) => { // request handler listens for POST request at /create
    const name = req.body.name; // varaible name will be set by the request in the body with the key name?
    names.push(name); //adds this new name variable to the list of names variable 
    res.send(`${name} added successfully`); // response to user to show the name was added successfully. 
// for this i went to postman selected post - typed in the URL with /create on the end
// selected body > raw and JSON. 
// typed in an array in the text box feild {"name" : "Steve"}
// this then gets added to the output'Steve' to the list of names of a get all browser refresh. 
});

//adds multiple names from postman to array created in JS
app.post('/multipleNames', (req, res) => {
    const name = req.body;

    for (let person of name) {
        names.push(person.name);
    }

    res.status(201).send(`Names added successfully`);
    // this time on postman i would need to select post - then /multiplenames URL.
    // select same options again. then create an array so use [] around all options, {}, around each option
});

// Replaces a name in the array with a name specified in a querey parameter at an index specified in a URL Parameter
app.put('/updateName/:id', (req,res) => {
// pulls through name from postman e.g. http://localhost:4400/updateName/0?name=Michael
// in the above url, we are taking the the index/id which is 0 (MS currently), and the new name,which is Michael.
const name = req.query.name;
const id = req.params.id;

// states old name if from the JS array at the same id
const old = names[id];
//takes location of old name, and uses to update old name to new name from postman
names[id] = name;
//confirms the changes have been made
res.status(202).send(`${old} successfully replaced with ${name}`);
});

const server = app.listen(4400, () => { //delcares the variable server which is being told to listen on port 4400?
    console.log("server started on", server.address().port); //output the server address. 
});

